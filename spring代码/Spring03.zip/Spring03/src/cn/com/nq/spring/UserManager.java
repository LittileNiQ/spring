package cn.com.nq.spring;

public class UserManager {
	private String usernmae;
	private String password;
	private String url;
	private String driverClass;
   public void setUsernmae(String usernmae) {
		this.usernmae = usernmae;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public void setDriverClass(String driverClass) {
		this.driverClass = driverClass;
	}
public void add(User user)
   {
	   //ִ��
	   System.out.print(usernmae);
	   System.out.print("ִ������user�Ĳ���");
   }
} 
