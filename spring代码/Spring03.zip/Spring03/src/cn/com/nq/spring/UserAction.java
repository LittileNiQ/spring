package cn.com.nq.spring;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;

public class UserAction implements BeanFactoryAware{
	private UserManager manager = null;
    private List list=null;
	private Set set=null;
	private Map map=null;
	private Properties props=null;
	
	public String excute(){
	//	BeanFactory factory = new ClassPathXmlApplicationContext("applicationContext.xml");
		User user=new User();
	    manager=(UserManager)factory.getBean("userManager");
		manager.add(user);
		return "sucsess";
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

	public Set getSet() {
		return set;
	}

	public void setSet(Set set) {
		this.set = set;
	}

	public Map getMap() {
		return map;
	}

	public void setMap(Map map) {
		this.map = map;
	}

	public Properties getProps() {
		return props;
	}

	public void setProps(Properties props) {
		this.props = props;
	}

	public void setManager(UserManager manager) {
		System.out.print("������set����");
		this.manager = manager;
	}

	private BeanFactory factory=null; //BeanFactory��д��excute()������
	@Override
	public void setBeanFactory(BeanFactory factory) throws BeansException {
	   	this.factory=factory;
	}

}
