package cn.com.nq.spring;

import java.util.Iterator;
import java.util.Map.Entry;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// ����Spring Bean����
	//	BeanFactory factory = new ClassPathXmlApplicationContext("applicationContext.xml");
		BeanFactory factory =new ClassPathXmlApplicationContext("app*.xml");//��ͨ�������
	    
		UserAction ua=(UserAction) factory.getBean("userAction");
//	    System.err.println(ua);
//		System.out.println(ua.excute());
//	    ua=(UserAction) factory.getBean("userAction");
//	    System.err.println(ua);
//		System.out.println(ua.excute());
//		
//	    ua=(UserAction) factory.getBean("userAction");
//	    System.err.println(ua);
//		System.out.println(ua.excute());
		for(Object o:ua.getList()){
			System.out.println(o);
		}
		
		System.out.println("-------------------------------");
		
		for(Object o:ua.getSet()){
			System.out.println(o);
		}
		
		System.out.println("-------------------------------");
        
		for(Iterator iter=ua.getMap().entrySet().iterator();iter.hasNext();)
		{
			Entry entry=(Entry) iter.next();
			System.out.println(entry.getKey()+":"+entry.getValue());
		}
	}
}
